package com.example.isaacvasquez.mapa;

/**
 * Created by isaacvasquez on 19/11/17.
 */

import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;
import com.google.firebase.messaging.FirebaseMessagingService;




public class MyFirebaseInstanceIDService extends FirebaseInstanceIdService {




    private static final String TAG = "firebase token";


    @Override


    public void onTokenRefresh() {


        String token = FirebaseInstanceId.getInstance().getToken();


        System.out.println("Token firebase" + token);







    }







    private void enviarTokenRegistro(String token){


        Log.d(TAG,token);


    }


}
