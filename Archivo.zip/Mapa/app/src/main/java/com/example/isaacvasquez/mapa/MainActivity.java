package com.example.isaacvasquez.mapa;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

//import android.support.v7.app.ActionBarActivity;


public class MainActivity extends AppCompatActivity {

    ViewPagerAdapter mSectionsPagerAdapter0;
    ViewPagerAdapter mSectionsPagerAdapter;
    ViewPagerAdapter mSectionsPagerAdapter1;
    ViewPagerAdapter mSectionsPagerAdapter2;
    ViewPager mViewPager0;
    ViewPager mViewPager;
    ViewPager mViewPager1;
    ViewPager mViewPager2;
    public String[] mCircuito;
    //String[] titulo = getResources().getStringArray(R.array.categorias);


    protected static Integer[] mImageIds = {

            R.drawable.circuitolunar,

            R.drawable.rs81,
            R.drawable.rsonytablet,
            R.drawable.riphone7,
            R.drawable.circuito_delsol,
            R.drawable.circuito_verde,
            R.drawable.circuito_delrio,

            R.drawable.riphonex,
            R.drawable.riphonex,
            R.drawable.riphonex,
            R.drawable.riphonex,
            R.drawable.riphonex,


            R.drawable.riphone6,
            R.drawable.riphone6,
            R.drawable.riphone6,



    };

    ListView lista;
    String[] personas = {
            "apple1",
            "apple2",
            "apple3",
            "apple4",
            "apple5",
            "apple6",
            "apple7",
            "apple8",
            "apple9"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // LISTVIEW //
     //   lista = (ListView) findViewById(R.id.listViewHome);
     //   ArrayAdapter adaptador = new ArrayAdapter(this, android.R.layout.simple_list_item_1, personas);
     //   lista.setAdapter(adaptador);
     //   lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
     //       @Override
     //       public void onItemClick(AdapterView adapterView, View view, int i, long l) {
     //           Toast.makeText(getApplicationContext(), "posicion " + (i+1) + personas[i], Toast.LENGTH_SHORT).show();
     //       }
     //   });
        //FIN LISTVIEW

        //VIEWPAGER
        mCircuito = getResources().getStringArray(R.array.circuito);

        mSectionsPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());

        mViewPager = (ViewPager) findViewById(R.id.pager);

        mSectionsPagerAdapter.addFragment(Fragmentos.newInstance(1,mCircuito[1], mImageIds[1]));
        mSectionsPagerAdapter.addFragment(Fragmentos.newInstance(2,mCircuito[2], mImageIds[2]));
        mSectionsPagerAdapter.addFragment(Fragmentos.newInstance(3,mCircuito[3], mImageIds[3]));
     //   mSectionsPagerAdapter.addFragment(Fragmentos.newInstance(4,mCircuito[4], mImageIds[4]));
     //   mSectionsPagerAdapter.addFragment(Fragmentos.newInstance(5,mCircuito[5], mImageIds[5]));
     //   mSectionsPagerAdapter.addFragment(Fragmentos.newInstance(6,mCircuito[6], mImageIds[6]));

        mViewPager.setAdapter(mSectionsPagerAdapter);


        mSectionsPagerAdapter1 = new ViewPagerAdapter(getSupportFragmentManager());
        mViewPager1 = (ViewPager) findViewById(R.id.pager1);
        mSectionsPagerAdapter1.addFragment(Fragmentos.newInstance(7,mCircuito[7], mImageIds[7]));
        mSectionsPagerAdapter1.addFragment(Fragmentos.newInstance(8,mCircuito[8], mImageIds[8]));
        mSectionsPagerAdapter1.addFragment(Fragmentos.newInstance(9,mCircuito[9], mImageIds[9]));
        mSectionsPagerAdapter1.addFragment(Fragmentos.newInstance(10,mCircuito[10], mImageIds[10]));



        mViewPager1.setAdapter(mSectionsPagerAdapter1);




        mSectionsPagerAdapter2 = new ViewPagerAdapter(getSupportFragmentManager());
        mViewPager2 = (ViewPager) findViewById(R.id.pager2);
        mSectionsPagerAdapter2.addFragment(Fragmentos.newInstance(11,mCircuito[11], mImageIds[11]));
        mSectionsPagerAdapter2.addFragment(Fragmentos.newInstance(12,mCircuito[12], mImageIds[12]));
        mSectionsPagerAdapter2.addFragment(Fragmentos.newInstance(13,mCircuito[13], mImageIds[13]));



        mViewPager2.setAdapter(mSectionsPagerAdapter2);



        mSectionsPagerAdapter0 = new ViewPagerAdapter(getSupportFragmentManager());
        mViewPager0 = (ViewPager) findViewById(R.id.pager0);
        mSectionsPagerAdapter0.addFragment(Fragmentos.newInstance(0,mCircuito[0], mImageIds[0]));




        mViewPager0.setAdapter(mSectionsPagerAdapter0);

        //FIN VIEWPAGER



    }




    /****************** VIEWPAGER *********************/
    public class ViewPagerAdapter extends FragmentPagerAdapter {
        List<Fragment> fragments; //


        public ViewPagerAdapter(FragmentManager fm) {
            super(fm);
            fragments = new ArrayList<Fragment>();
        }

        @Override
        public Fragment getItem(int position) {

            return fragments.get(position);
        }

        @Override
        public int getCount() {

            return this.fragments.size();
        }

        public void addFragment(Fragment xfragment){
            this.fragments.add(xfragment);
        }
    }
    /****************** FIN VIEWPAGER *********************/

    /****************** FRAGMENTOS *********************/
    public static class Fragmentos extends Fragment {
        /**
         Agregue "color"
         */
        private static final String CURRENT_VIEWVAPER ="currentviewpager";
        private static final String NOMBRE_CIRCUITO = "circuito";
        private static final String IMAGEVIEW = "image";

        private int currentViewPager;
        private String nombre_circuito;
        private int image;

        public static Fragmentos newInstance(int currentViewPager, String circuitoNombre, int image) {

            Fragmentos fragment = new Fragmentos();

            Bundle args = new Bundle();
            args.putInt(CURRENT_VIEWVAPER, currentViewPager);
            args.putString(NOMBRE_CIRCUITO, circuitoNombre);
            args.putInt(IMAGEVIEW, image);
            fragment.setArguments(args);
            fragment.setRetainInstance(true);
            return fragment;
        }

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);


            if(getArguments() != null){
                this.currentViewPager = getArguments().getInt(CURRENT_VIEWVAPER);
                this.nombre_circuito = getArguments().getString(NOMBRE_CIRCUITO);
                this.image = getArguments().getInt(IMAGEVIEW);
            }
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_circuito, container, false);

            TextView tv_circuito = (TextView) rootView.findViewById(R.id.tv_circuito);
            tv_circuito.setText(nombre_circuito);

            ImageView frg_image = (ImageView) rootView.findViewById(R.id.frg_imageView);
            frg_image.setImageResource(image);
            frg_image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(getActivity(), ListarCircuito.class);
                    i.putExtra("currentViewPager", currentViewPager);
                    i.putExtra("nombreCircuito", nombre_circuito);
                    startActivity(i);
                    //overridePendingTransition(R.anim.left_in, R.anim.left_out);
                }
            });
            return rootView;
        }
    }
    /****************** FIN FRAGMENTOS *********************/


}
